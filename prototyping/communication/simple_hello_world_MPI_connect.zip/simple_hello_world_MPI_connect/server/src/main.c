// This is the server
// Using Intel MPI 4.0.3
// Starting the server with (mpdboot running) 
//   mpiexec -np 1 ./server
// and the client 
//   mpiexec -np 1 ./client 
// ===> This combination works ==> The Server prints "Connected"
// However using mpirun as recommended in the doc does not work
// Why does it not work? IS there a need to start some service 
// in order to support MPI_Publish_name and MPI_Lookup_name ?
   
#include <stdio.h>
#include <mpi.h>
#include <string.h>

#define MAX_DATA 1000 
int main( int argc, char **argv ) 
{ 
    MPI_Comm client; 
    char port_name[MPI_MAX_PORT_NAME]; 
    int    size; 
    char serv_name[256];
    strcpy( serv_name, "MyTest" );
 
    MPI_Init( &argc, &argv ); 
    MPI_Comm_size(MPI_COMM_WORLD, &size); 
    MPI_Open_port(MPI_INFO_NULL, port_name); 
    MPI_Publish_name(serv_name,MPI_INFO_NULL, port_name);
    printf("server available at %s\n",port_name); 

    MPI_Comm_accept( port_name, MPI_INFO_NULL, 0, MPI_COMM_WORLD,  
                         &client ); 
    printf("Connected\n");
    MPI_Comm_disconnect(&client);
    MPI_Finalize();

}
